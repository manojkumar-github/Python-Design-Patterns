


def compute_percentile(ip_arr):
    """

    Args:
        ip_arr:

    Returns:

    """
    ip_arr.sort()
    percentile_map = {}
    n = len(ip_arr)
    for ix, val in enumerate(ip_arr):
        if ix == 0:
            percentile_map[val] = 0
        else:
            percentile_map[val] = ix/float(n-1) * 100
    return percentile_map

ip_array = [12, 60.9, 80, 71, 30]
print(compute_percentile(ip_array))


def report_pth_percentile(ip_arr, p):
    """
    numpy percentile
    scipy stats
    pandas rank

    Args:
        ip_arr:
        p:

    Returns:

    """
    ip_array.sort() # O(nlogn)
    index = p * float(len(ip_arr)-1) * 1/100
    if int(index) == float(index):
        return ip_array[int(index)]
    else:
        print(index)
        return None

print(report_pth_percentile(ip_array, 25))

