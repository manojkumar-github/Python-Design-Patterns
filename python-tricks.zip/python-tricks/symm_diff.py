"""
This module contains the functions to compute the symmetric difference
between two sorted lists
"""


import os
import unittest

class SymmDiffer:

    def _load_chunk_of_file(self, file_path: str, line_num: int) -> list:
        """
            Loads chunk of file
        Args:
            file_path (str): Local file path
            line_num (int): Line number in file

        Returns:
            list: List of items in each line of the file
        """
        with open(file_path, "r") as f:
            file_chunk_ids = []
            for row_idx, line in enumerate(f):
                if row_idx > line_num:
                    return file_chunk_ids
                else:
                    file_chunk_ids.append(line.rstrip())
            return file_chunk_ids


    def _load_first_item_of_file(self, file_path: str) -> str:
        """
            Loads first item of the file
        Args:
            file_path: Local file path

        Returns:
            str: First item of the file
        """
        return self._load_chunk_of_file(file_path, 1)[0]


    def _load_last_item_of_file(self, file_path: str) -> str:
        """
            Loads last item of the file
        Args:
            file_path (str): Local file path

        Returns:
            str: Last item of file
        """
        with open(file_path, "rb") as f:
            f.seek(-2, os.SEEK_END)
            while f.read(1) != b'\n':
                f.seek(-2, os.SEEK_CUR)
            return f.readline().decode()


    def _load_full_file(self, file_path: str):
        """
            Loads full file and returns item in list
        Args:
            file_path (str): Local file path

        Returns:
            list: list of items as integers
        """
        with open(file_path, "r") as f:
            return [int(line.rstrip()) for line in f]


    def symmetric_diff_on_sorted_integers(self, file1_path: str, file2_path: str):
        """
            Performs symmetric difference on sorted items between two files
        Args:
            file1_path (str): File 1 path
            file2_path (str): File 2 path

        Returns:
            list: List of items that do not exist in intersection of two files
        """
        file_1_max = int(self._load_last_item_of_file(file1_path))
        file_2_min = int(self._load_first_item_of_file(file2_path))

        if file_1_max < file_2_min:
            return  self._load_full_file(file1_path) + self._load_full_file(
                file2_path)
        elif file_1_max == file_2_min:
            return self._load_full_file(file1_path)[:-1] + \
                   self._load_full_file(file1_path)[1:]
        else:
            file_1_ids = self._load_full_file(file1_path)
            file_2_ids = self._load_full_file(file2_path)

            n_file_1 = len(file_1_ids)
            n_file_2 = len(file_2_ids)
            i = 0
            j = 0
            symm_diff_op = []
            while i < n_file_1 and j < n_file_2:
                if file_1_ids[i] < file_2_ids[j]:
                    symm_diff_op.append(file_1_ids[i])
                    i += 1
                elif file_1_ids[i] > file_2_ids[j]:
                    symm_diff_op.append(file_2_ids[j])
                    j += 1
                else:
                    i += 1
                    j += 1
            while i < n_file_1:
                # add remaining items from file 1
                symm_diff_op.append(file_1_ids[i])
                i += 1
            while j < n_file_2:
                # add remaining items from file 2
                symm_diff_op.append(file_2_ids[j])
                j += 1
            return symm_diff_op


class TestSymmDiffer(unittest.TestCase):
    """ Test case class for Symm Differ"""

    def setUp(self) -> None:
        """
            File 1 data = [3, 4, 5, 6, 7]
            File 2 data = [1, 2, 3, 4, 5]
        Returns:

        """
        self.file1_path = "file1.txt"
        self.file2_path = "file2.txt"
        self.symm_diff_obj = SymmDiffer()

    def test_01_file1_to_file2(self):
        """

        Returns:

        """
        expected_result = [1, 2, 6, 7]
        actual_result = \
            self.symm_diff_obj.symmetric_diff_on_sorted_integers(
                self.file1_path, self.file2_path)
        self.assertEqual(expected_result, actual_result)

    def test_02_file2_to_file1(self):
        """

        Returns:

        """
        expected_result = [1, 2, 6, 7]
        actual_result = \
            self.symm_diff_obj.symmetric_diff_on_sorted_integers(
                self.file2_path, self.file1_path)
        self.assertEqual(expected_result, actual_result)


if __name__=="__main__":
    unittest.main()
