# Programmer Interview Exercise

The following instructions will guide you on how to answer the 2 questions in the
programming test phase of the Simulation Programmer selection process.


## General Notes:

* Fetch the test files from <http://www.icecube.wisc.edu/~jcdiazvelez/ProgrammerExercise.zip>
 Once you unpack the zip file, you will have this file (as `README.md`) and other files related
 to the test questions. These will be listed with the explanation for the questions

* To answer these questions, the programmer can use search engines such as Google,
 send email to the selection test contact address <juancarlos@icecube.wisc.edu>
 asking for more details, etc., but should not ask for outside assistance in answering the
 questions.

* Be prepared to discuss how the program could be made more readable as well as
 any other improvements you might make or best practices you would use when
 working on this code in a team environment.
    
* Please email your solution to <juancarlos@icecube.wisc.edu>
    
 

## Exercise Question 1 
 ### files: threads.py
  
 ### synopsis:
The threads.py script is an attempt to process an input data *stream* using multiple threads.
Specifically, there are 1000 data points to be processed using 100 threads. The length of the input is
restricted to 1000 for the purpose of this exercise, but in practice, it will be continuous input.
Each input from the stream is identified by an index, in this case, the input number itself. The time taken for each
process, represented here by a simple sleep delay, follows a uniform distribution with a little jitter.
However, we occasionally get an input data that takes an order of magnitude longer than what is typical.


The tasks processed by each thread instance take varying lengths of time, so, simply calling `self.output.append(val)`
as is currently done in the "put" method will *not* guarantee that the output of the processing is ordered by the input index.
Processing of an (n+1)th input may be completed before processing of the nth or earlier inputs are completed.


Since this is a *stream* that is being collected on a continual basis, and the storage/buffer is finite,
sorting the results in `data.output` after all the results have been assembled is *not* a desired solution.
The requirement is that the `data.output` is sorted on the *fly*, that is, the order in `data.input` *must* be maintained at the
time that the results are being updated in the `data.output` result list. `data.output` *cannot* be updated with the result from
processing the (n+1)th input if it does not already contain results from processing the nth, (n-1)th, (n-2)th ...... inputs.



 ### tasks:
Modify the "put" method of "TheData" class to:
1. process and produce an **ordered** output
2. in an **efficient** manner


 ### others
* It is suggested that you use some of the capabilities for coordinating the activities of multiple threads documented here:
[https://docs.python.org/2/library/threading.html](https://docs.python.org/2/library/threading.html)
[https://docs.python.org/3/library/threading.html](https://docs.python.org/3/library/threading.html)

* You are also free to make other changes to improve the scripts as you deem fit.
  
    
    
## Exercise Question 2
 ### files: read_moni_file.py, read_moni_file_test.py, stringHub-80.moni


 ### synopsis:
The program uses regular expressions to parse an input file produced as part
of DAQ operations ("StringHub monitoring data file").  These data files are
formatted like:

Category: Date
Field1: Value1
Field2: Value2

As written, the program reads in the data from a file and stores it as either
a Python int, a float, or a string.

 ### tasks:
1. Modify the program so that arrays in the input are parsed to actual Python
dictionaries and arrays, rather than just strings.

2. What is the test coverage of the unit test (% of lines covered), before and
after your changes?

3. Fill in the check_root() method.  This method use the disk usage data from
the file to estimate the time remaining before the root ("/") partition is
full.


 ### others
*Quick `re` tutorial*
---------------------

The program uses a couple of regular expressions, which are a powerful tool
for extracting information from a block of text.  The solution to the problem
above does not require regular expressions, but you may wish to read this
section if you find you need to understand what is happening in the body of
the program.

In the program, the `CATTIME_PAT` pattern matches the "Category: Date" string.
It does this by describing two groups, marked by parentheses.  The first group
is at the beginning of the string (in regular expressions, the beginning of a
string is indicated with a caret "^").  The first group pattern is "([^:]+)",
which matches one or more characters which are not a colon ":".  The "[^:]"
means "a character which is not a colon", and the plus sign "+" means "match
one or more of the previous pattern".  The second group follows a colon and
one or more whitespace characters ":\s+", because "\s" is a special sequence
which matches a space, tab, newline, carriage return, etc.  The second group
pattern is "(\d+-\d+-\d+\s\d+:\d+:\d+\.\d+)", which matches a date/time string.
This uses another special sequence "\d" to match any number character from 0 to
9.  The second group pattern thus matches a date string like "2011-02-11"
followed by a time string like "09:15:41.103247".  The pattern ends with "\s*",
which matches zero or more whitespace characters.

The `DATA_PAT` pattern "^(\s+)([^:]+):\s+(.*\S)\s*" matches three groups.  The
first group "(\s+)" matches one or more whitespace characters.  The second
group "([^:]+)" matches one or more characters which are not colons.  The
third group "(.*\S)" matches zero or more of any character ".*" followed by
any non-whitespace character "\S".
