#!/usr/bin/env python

import random
import threading
import time

def Machine(data):
    while True:
        # attempt to get next data
        try:
            input = data.get()
        # stop after getting 1000 inputs (this restriction is only set for the purpose of this exercise, in practice, it will be a continual stream of input data)
        except:
            break
        
        # processing time, mostly short with occasional much longer duration
        ProcessingTime = min(random.expovariate(0.9),100)

        time.sleep(ProcessingTime)
        data.put(input)

class TheData:
    def __init__(self,input):
        self.input = input
        self.output = []

    def get(self):
        return self.input.pop(0)
    def put(self,val):
        self.output.append(val)


def ProcessData():
    # assume the data is complex, but there is an order
    # which in this case is just the number
    data = TheData(input=range(1000))
    
    # make threads
    threads = []
    for n in range(100):
        m = threading.Thread(target=Machine,args=(data,))
        m.start()
        threads.append(m)

    for m in threads:
        m.join()
    print len(data.output)
    print len(data.input)
    return data.output


    
if __name__ == '__main__':

    timer = time.time()

    # currently not ordered, needs to be fixed
    OrderedOutput = ProcessData()
    print "Ordered output:\n",OrderedOutput

    print "Time taken (seconds): ", time.time()-timer


