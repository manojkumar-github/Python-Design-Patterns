#!/usr/bin/env python

import datetime
import os
import sys
import tempfile
import unittest

from read_moni_file import MonitorFile


class MonitorFileTest(unittest.TestCase):
    """
    Basic test suite for MonitorFile
    """
    RAW_DATA = {
        datetime.datetime(2011, 1, 1, 1, 1, 1, 1): {
            "abc": {"degree": 12.1, "high": 6, "low": 3},
            "def": {"state": "start"},
            "ghi": {"values": [1, 2, 3]}
            },
        datetime.datetime(2011, 1, 1, 1, 2, 1, 2): {
            "abc": {"degree": 13.2, "high": 9, "low": 3},
            "def": {"state": "running"},
            "ghi": {"values": [4, 5, 6]}
            },
        datetime.datetime(2011, 1, 1, 1, 3, 1, 3): {
            "abc": {"degree": 11.1, "high": 12, "low": 3},
            "def": {"state": "running"},
            "ghi": {"values": [5, 4, 3]}
            },
        datetime.datetime(2011, 1, 1, 1, 3, 1, 4): {
            "abc": {"degree": 9.3, "high": 13, "low": 3},
            "def": {"state": "done"},
            "ghi": {"values": [0, 0, 0]}
            },
        }

    def setUp(self):
        pass

    def tearDown(self):
        pass

    def compare_data(self, good_data, new_data):
        for t in good_data.keys():
            if not t in new_data:
                self.fail("New data does not have time key \"%s\"" % t)
            for k in good_data[t].keys():
                if not k in new_data[t]:
                    self.fail("New data does not have category key \"%s\"" % k)
                for n in good_data[t][k].keys():
                    if not n in new_data[t][k]:
                        self.fail("New data does not have name key \"%s\"" % n)
                    self.assertEqual(good_data[t][k][n], new_data[t][k][n])

    def testParse(self):
        (fd, path) = tempfile.mkstemp(text=True)
        with os.fdopen(fd, "w") as out:
            MonitorFile.write_data_to_file(out, self.RAW_DATA)

        try:
            mf = MonitorFile(path)
        finally:
            os.unlink(path)

        self.compare_data(self.RAW_DATA, mf._data)


if __name__ == '__main__':
    unittest.main()
