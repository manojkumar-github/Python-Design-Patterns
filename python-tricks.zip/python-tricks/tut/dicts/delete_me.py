import copy
def print_three_digit(ip_num):
    # here we receiving the various kind of numbers
    # first we should find if those are 3 digit or not
    # if those are 3 digit, then we should see if all thse are uniquw
    # if those are unique we should print and add them

    """We will have a while loop to find the number of digits"""
    n_digits = 0
    org_num = copy.deepcopy(int(ip_num)) # copy original number
    while(ip_num>0):
        ip_num = ip_num//10 # integer division not float division 0
        n_digits = n_digits + 1


    # to capture n_digits



    # THIS CODE CORRECT
    # NO NEED TO CHANGE 12
    digits_list = []
    while ip_num//10>0: # this is the condition
        ip_num = ip_num // 10 # this to keep decreasing the number  - 12
        this_digit = ip_num % 10 # this to capture remainder that is each - 3
        digits_list.append(this_digit) # append each digit

    # loop exists after we encounter a single digit that ip_num//10 becomes 0




    -123
    0
    -1
    +1
    1.5
    0.5
    -0.5
    -inf
    +inf
    13131412424214901499014 - some large digit number (size of int and \
                                                               long-int in python)




    Negative
    Float
    String alphabets


    # to print sum
    print(sum(digits_list))


    """
    What I would do is using the same for loop
    Instead doing instaead of interger division, I get remainder
    usin %
    """
    # assuming ip_num as integer

    while (ip_num>0):








    # now we have got number of digits
    # we will check if n_digits is 3

    if n_digits == 3:
        # now we have to check if all digits are unique
        seen = [] # captures all digits in integer
        str_digit = str(org_num)
        for each_digit in str_digit:
            if each_digit not in str_digit:
                seen.append(int(each_digit)) # see here we are converting
                # string to int
        if len(seen) == 3:
            print(org_num) # we can print sum
            print(sum(seen)) # add all digits
if __name__ == "__main__":
    number = input()
    print_three_digit(number)

