from string_dups import *

def test_duplicates(data, expected):
    dup = Stringclass()
    res = dup.remove_str_duplicates(data)
    print('result is', res)
    assert res == expected, "function is failed"
    return True

if __name__ == '__main__':

    TY = test_duplicates('QWQWSSD', 'miss_qwsd_suffix')
    print('test result = ', TY)