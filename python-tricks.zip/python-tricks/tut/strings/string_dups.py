# class Stringclass():
#     x = '_suffix'
#     def remove_str_duplicates(self, astring, prefix='miss_'):
#        empty = ''
#        for i in range(len(astring)):
#         if astring[i].isupper():
#             var = astring[i].lower()
#         else:
#             var = astring[i]
#         if var not in empty:
#             empty += var
#        return prefix+empty+Stringclass.x
#
#     def get_duplictes(self):
#         pass
#
# def compress(astring):
#
#     # ip = aaabbbcdeaac,  op : a3b3c1d1e1a2c1
#     n = len(astring)
#     if n == 1 or n == 0:
#         return astring
#
#     op_string = ""
#
#     count = 0
#     for i in range(1, n):
#         if astring[i-1] == astring[i]:
#             count += 1
#         else:
#             op_string += astring[i-1]+str(count+1)
#             count = 0 # refresh
#
#     return op_string
#
#
#
# print(compress('aaabbbcdeaac'))
#
# def decompress(astring):
#     """
#     ip = a3b3c3e2d2a2c1a1d1f1a1k1j1l1c1'
#     op = 'aaabbbccceeddaacadfakjlc'
#     :param astring:
#     :return:
#     """
#     n = len(astring)
#     new_str = ""
#     for i in range(1, n, 2):
#         current_string = astring[i-1]
#         new_str += current_string * int(astring[i])
#     return new_str
#
# print (decompress('a3b3c3e2d2a2c1a1d1f1a1k1j1l1c1'))
#
#
# def print_count_occurences(astring):
#     """Input - 'abbaccdbac', Output - 'a3b3c3d1'"""
#     # O(n^2)
#     # O(n)
#
#     mymap = {} # {'a': 3, 'b':3}
#     for i in range(len(astring)):
#         if astring[i] not in mymap.keys():
#             mymap[astring[i]] = 1
#         else:
#             mymap[astring[i]] += 1
#     new_str = ""
#     for key, value in mymap.iteritems():
#         new_str += (key+str(value))
#     return new_str
#
# print (print_count_occurences('abbaccdbac'))
#
#
#


def print_stack():
    # stack = LIFO
    jaffa = []
    for i in range(10):
        jaffa.append(i)
    print("queue before pop()",jaffa)
    for i in range(10):
        print(jaffa.pop(0), jaffa)
print_stack()