


def is_even(num):
    """

    :param num:  a digit
    :return: boolean
    """
    if num % 2 == 0:
        return True
    else:
        return False

print ("Given number {} is even: {}".format(4, is_even(4)))
print ("Given number {} is even: {}".format(5, is_even(5)))



