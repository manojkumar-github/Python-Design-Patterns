class Node:
    def __init__(self, key):
        self.right = None
        self.left = None
        self.val = key

def printInOrder(root):
    if root:
        # First recurse completely on left child
        printInOrder(root.left)

        print(root.val)

        # recurse completely on right child
        printInOrder(root.right)


def printPostOrder(root):
    if root:
        printPostOrder(root.left)
        printPostOrder(root.right)
        print(root.val)

def printPreOrder(root):
    if root:
        print (root.val)
        printPreOrder(root.left)
        printPreOrder(root.right)


# Driver code
root = Node(1)
root.left = Node(2)
root.right = Node(3)
root.left.left = Node(4)
root.left.right = Node(5)
print "Preorder traversal of binary tree is"
printPreOrder(root)

print "\nInorder traversal of binary tree is"
printInOrder(root)

print "\nPostorder traversal of binary tree is"
printPostOrder(root)