"""
Greedy Algorithm:
a) always choose the next step that offers the maximum benefit
b) used for optimization problems

Fractional Knapsack = greedy vs 0-1 Knapsack = dp

Activity Selection problem
"""

def max_activity_selection(n, start_list, finish_list):
    """activities are already started accoring to their finish times
    start[]  =  {1, 3, 0, 5, 8, 5};
    finish[] =  {2, 4, 6, 7, 9, 9};"""
    assert len(start_list) == n
    assert len(finish_list) == n
    i = 0
    print i
    for j in range(1, n):
        if start_list[j] >= finish_list[i]:
            print j
            i = j
    print ("done")


max_activity_selection(6, [1, 3, 0, 5, 8, 5],[2, 4, 6, 7, 9, 9])



