"""
If N = 1
   Count(i, j, N) = 10
Else
   Count(i, j, N) = Sum of all Count(r,c,N-1) where r and c are 
   the position after valid move of the length 1 from current position
   i and j.
"""

row = [0,0,-1,0,1]
col = [0,-1,0,1,0]
def util1(keypad, i, j ,n):
	"""
	Returns count of numbers of length n starting
	from current position (i,j)
	keypad: 4*3 matrix

	"""
	if keypad == NULL || n <= 0:
		return

	# From a given key, only one number is possible of 
	# length 1
	if (n==1): return 1

	k = 0, move = 0, ro = 0, co = 0, totalCount = 0



def possible_numbers_mobile_keypad(N):
	# it is a 4*3 matrix

