from itertools import product
def print_all_possible_words_from_phone_digits(ip_num):
	query_map = {2:"ABC",
	   			3:"DEF",
	   			4:"GHI",
	   			5:"JKL",
	   			6:"MNO",
	   			7:"PQRS",
	   			8:"TUV",
	   			9:"WXYZ"}
	string_maps = []

	while ip_num > 0:
		this_digit = ip_num % 10
		ip_num = ip_num // 10
		string_maps = [query_map[this_digit].lower()] + string_maps

	result = list(product(*string_maps))
	new_result = ["".join(each) for each in result]
	return sorted(new_result)
	
print(print_all_possible_words_from_phone_digits(234))



