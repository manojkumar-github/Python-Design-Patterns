def matrix_multi_recursive(matrix1, matrix2):

    assert len(matrix1) == len(matrix2[0])
    result = [[0,0,0]]
    for i in range(len(matrix1)):
        for j in range(len(matrix2[0])):
