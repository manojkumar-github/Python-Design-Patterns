def matrix_roation(matrix):
    if not len(matrix):
        return None

    """
    top: start row of the index
    bottom: ending row of the index
    left: starting column of the index
    right: ending column of the index
    """
    top = 0
    bottom = len(matrix) - 1

    left = 0
    right = len(matrix[0]) - 1


    while left < right and top < bottom:
        # store the first element of the next row
        previous = matrix[top+1][left]
        # move elements of top row one step right
        for i in range(left, right+1):
            current = matrix[top][i]
            matrix[top][i] = previous
            previous = current
        top +=1

        # move elements of rightmost column one step downwards
        for i in range(top, bottom+1):
            current = matrix[i][right]
            matrix[i][right] = previous
            previous = current

        right -= 1

        # move elements of bottom column one step left
        for i in range(right, left-1, -1):
            current = matrix[bottom][i]
            matrix[bottom][i] = previous
            previous = current

        bottom -= 1

        # move elements of left most column one step upwards
        for i in range(bottom, top-1, -1):
            current = matrix[i][left]
            matrix[i][left] = previous
            previous = current

        left += 1

    return  matrix

def printMatrix(matrix):
    for row in matrix:
        print (row)

if __name__ == "__main__":
    matrix = [[1,2,3,4],
              [5,6,7,8],
              [9,10,11,12],
              [13,14,15,16]]
    printMatrix(matrix)
    print ("------------------------")
    rotated_matrix = matrix_roation(matrix)
    printMatrix(rotated_matrix)

