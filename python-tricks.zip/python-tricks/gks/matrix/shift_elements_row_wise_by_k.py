"""
Input : mat[N][N] = {{1, 2, 3},
                     {4, 5, 6},
                     {7, 8, 9}}
        k = 2
Output :mat[N][N] = {{3, 1, 2}
                     {6, 4, 5}
                     {9, 7, 8}}

Input : mat[N][N] = {{1, 2, 3, 4}
                     {5, 6, 7, 8}
                     {9, 10, 11, 12}
                     {13, 14, 15, 16}}
        k = 2
Output :mat[N][N] = {{3, 4, 1, 2}
                     {7, 8, 5, 6}
                     {11, 12, 9, 10}
                     {15, 16, 13, 14}}

Note: Matrix should be a square matrix
"""

N = 4

def shift_elem_row_wise_by_k(matrix, k):
    if k>N:
        print ('Shifting is not possible')
        return

    j = 0
    while j < N:
        # print elements from index k
        for i in range(k, N):
            print ("{}".format(matrix[j][i], end=","))
        # print elements before index k
        for i in range(0, k):
            print("{}".format(matrix[j][i], end=""))
        print ("")
        j = j + 1

# Driver code
mat = [[1, 2, 3, 4],
           [5, 6, 7, 8],
           [9, 10, 11, 12],
           [13, 14, 15, 16]]
k = 2

# Function call
shift_elem_row_wise_by_k(mat, k)







