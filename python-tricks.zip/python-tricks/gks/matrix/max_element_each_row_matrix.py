
def max_elem_matrix(matrix):
    max = -1
    for row in matrix:
        for elem in row:
            if elem > max:
                max = elem
        print (max)



if __name__ == "__main__":
    # Driver Code
    arr = [[3, 4, 1, 8],
           [1, 4, 9, 11],
           [76, 34, 21, 1],
           [2, 1, 4, 5]]

    max_elem_matrix(arr)