"""
The problem can be solved in O(n log n) time using the recursive divide and
conquer approach, e.g., as follows:[1]

Sort points according to their x-coordinates.
Split the set of points into two equal-sized subsets by a vertical line x=xmid.
Solve the problem recursively in the left and right subsets. This yields the
left-side and right-side minimum distances dLmin and dRmin, respectively.
Find the minimal distance dLRmin among the set of pairs of points in which
one point lies on the left of the dividing vertical and the other point lies
to the right.
The final answer is the minimum among dLmin, dRmin, and dLRmin.
"""

from operator import itemgetter, attrgetter

infinity = float('inf')


def bruteForceClosestPair(point):
    numPoints = len(point)
    if numPoints < 2:
        return infinity, (None, None)
    return min( ((abs(point[i] - point[j]), (point[i], point[j]))
                 for i in range(numPoints-1)
                 for j in range(i+1,numPoints)),
                key=itemgetter(0))


def closestPair(points):
    xP = sorted(points, key=attrgetter('real'))  # sorted list of all
    # x-coordinate points

    # sorted list of all y-coordinate points
    yP = sorted(points, key=attrgetter('imag'))
    return _closestPair(xP, yP)


def _closestPair(xP, yP):
    numPoints = len(xP)
    if numPoints <= 3:
        return bruteForceClosestPair(xP)
    Pl = xP[:numPoints/2]
    Pr = xP[numPoints/2:]
    Yl, Yr = [], []
    xDivider = Pl[-1].real
    for p in yP:
        if p.real <= xDivider:
            Yl.append(p)
        else:
            Yr.append(p)
    dl, pairl = _closestPair(Pl, Yl)
    dr, pairr = _closestPair(Pr, Yr)
    dm, pairm = (dl, pairl) if dl < dr else (dr, pairr)
    # Points within dm of xDivider sorted by Y coord
    closeY = [p for p in yP  if abs(p.real - xDivider) < dm]
    numCloseY = len(closeY)
    if numCloseY > 1:
        # There is a proof that you only need compare a max of 7 next points
        closestY = min( ((abs(closeY[i] - closeY[j]), (closeY[i], closeY[j]))
                         for i in range(numCloseY-1)
                         for j in range(i+1,min(i+8, numCloseY))),
                        key=itemgetter(0))
        return (dm, pairm) if dm <= closestY[0] else closestY
    else:
        return dm, pairm



if __name__ == "__main__":
    pointList = [(5 + 9j), (9 + 3j), (2 + 0j), (8 + 4j), (7 + 4j), (9 + 10j),
                 (1 + 9j), (8 + 2j), 10j, (9 + 6j)]
    print (pointList)
    print (bruteForceClosestPair(pointList))
    print (closestPair(pointList))
