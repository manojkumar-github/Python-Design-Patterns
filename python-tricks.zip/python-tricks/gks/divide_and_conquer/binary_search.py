def binary_search_while(num, alist):
    n = len(alist)
    start = 0
    end = n-1
    found = False
    while start <= end and not found:
        middle = (start+end)/2
        if alist[middle] == num:
            found = True
        else:
            if num < alist[middle]:
                end = middle - 1
            else:
                start = middle + 1
    return found


def binary_search_recursion(num, alist):
    n = len(alist)
    if n == 0:
        return False
    else:
        middle = n//2
        if alist[middle] == num:
            return True
        else:
            if num < alist[middle]:
                return binary_search_recursion(num, alist[:middle])
            else:
                return binary_search_recursion(num, alist[middle+1:])

print (binary_search_recursion(11, [1,2,3,4,5,6,7,8,9,10]))


