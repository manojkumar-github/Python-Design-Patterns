def get_lis(seq):
    n_seq = len(seq)
    if n_seq < 2:
        return seq
    lis_seq = []

    for idx in range(n_seq-1):
        b_idx = [seq[idx]]
        while idx < n_seq-1:
            if seq[idx+1] >= b_idx[-1]:
                b_idx.append(seq[idx+1])
            idx +=1
        if len(b_idx) >= len(lis_seq):
            lis_seq = b_idx

    return lis_seq

if __name__ == "__main__":
    seq1 = [3,10,2,1,20]
    seq2 = [3,2]
    seq3 = [50,3,10,7,40,80]
    seq4 = [10, 22, 9, 33, 21, 50, 41, 60, 80]
    seq5 = [10 , 22 , 9 , 33 , 21 , 50 , 41 , 60]
    seq_list = [seq1, seq2, seq3, seq4, seq5]
    for seq in seq_list:
        print get_lis(seq)