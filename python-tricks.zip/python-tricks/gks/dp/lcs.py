def get_lcs(s1,s2):
    """
        Returns longest common sub-sequence
    :param s1:
    :param s2:
    :return:
    """
    new = ""
    for ch in s1:
        if ch in s2:
            if ch not in new:
                new = new+ch
    for each in new:
        if new in s2:
            prt

if __name__ == "__main__":
    s1 = 'ABCDGH'
    s2 = 'AEDFHR'
    s3 = 'AGGTAB'
    s4 = 'GXTXAYB'
    get_lcs(s3, s4)