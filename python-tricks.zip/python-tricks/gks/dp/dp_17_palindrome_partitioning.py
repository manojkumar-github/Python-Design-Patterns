"""
Pseudo Code:
a) If string is a pallindrome, then minimum number of cuts required is 0
b) If all characters in string are unique, the minimum number of cuts is n-1
for a string of length n
c) Else, recursively calculate the minimum number of cuts required for
different lenghts at each position
d) Use Dynamic Programming bottom up approach to store values of minimum
cuts and booleans
"""

def minPalPartition(astring):
    n = len(astring)

    cuts = [[0 for _ in range(n)] for _ in range(n)]
    is_palindrome = [[False for _ in range(n)] for _ in range(n)]

    # case where every substring of length 1 is a palindrome
    for i in range(n):
        cuts[i][i] = 0
        is_palindrome[i][i] = True

    for L in range(2, n+1):
        # iterate the below loop for each substring of length L
        for i in range(n-L+1):
            # end index
            j = i+L-1

            if L == 2:
                is_palindrome[i][j] = (astring[i] == astring[j])
            else:
                is_palindrome[i][j] = ((astring[i]==astring[j]) and
                                       is_palindrome[i+1][j-1])

            if is_palindrome[i][j] == True:
                cuts[i][j] = 0 # pallindrome case
            else:
                # make cut at every possible location at 'i' and 'j'
                cuts[i][j] = 1000000 # intiialize cost to a infinite value
                for k in range(i, j):
                    cuts[i][j] = min(cuts[i][j], cuts[i][k] + cuts[k+1][j] + 1)
    print(cuts)
    return cuts[0][n-1]



str1 = 'ababbbabbababa'
print(minPalPartition(str1))