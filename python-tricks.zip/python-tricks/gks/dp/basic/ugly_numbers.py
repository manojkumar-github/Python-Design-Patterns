"""
Given a number n , find the nth ugliest number
"""

def brute_force_ugly_number(n):
    """Space Complexity is O(1)"""
    ugly_number_count = 0
    this_num = 1
    def maxDivide(a, b):
        while a%b == 0:
            a = a/b
        return a

    def is_ugly_number(num):
        num = maxDivide(num, 2)
        num = maxDivide(num, 3)
        num = maxDivide(num, 5)
        return 1 if num == 1 else 0

    while ugly_number_count <= n:
        if is_ugly_number(this_num):
            ugly_number_count +=1
            if ugly_number_count == n:
                return this_num
        this_num +=1

no = brute_force_ugly_number(150)
print("150th ugly no. is ", no)

def ugly_numbers_dp(n):
    """Split sequence into three groups
    Every sequence is a subsequence itself"""
    ugly_list = [0] * n
    ugly_list[0] = 1
    i2,i3, i5 = 0, 0, 0
    next_multil


class Solution:
    def isUgly(self, num):
        """
        :type num: int
        :rtype: bool
        """
        return True if all(num%x==0 for x in [2,3,5]) else False

obj = Solution()
print(obj.isUgly(6))

