"""
Branch and bound - combinatorial optimization problems
Without these we end up running algorithms in exponential time and may
require all possible permutations in worst case
"""