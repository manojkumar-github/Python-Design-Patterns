"""
Find the smallest window in a string containing all characters of another string
Given two strings string1 and string2, find the smallest substring in
string1 containing all characters of string2 efficiently.
For Example:

Input :  string = "this is a test string"
         pattern = "tist"
Output :  Minimum window is "t stri"
Explanation: "t stri" contains all the characters
              of pattern.

Input :  string = "geeksforgeeks"
         pattern = "ork"
Output :  Minimum window is "ksfor"""


def smallest_window_of_string_of_another_string(string, pattern):
    if len(pattern) > len(string):
        raise Exception('Pattern cant be greater than string length')
    for char in pattern:
        pass
