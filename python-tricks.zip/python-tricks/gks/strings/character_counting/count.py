"""
Given a string, write a program to count the occurrence of Lowercase characters, Uppercase characters, Special characters and Numeric values.

Examples:

Input : #GeeKs01fOr@gEEks07
Output :
Upper case letters : 5
Lower case letters : 8
Numbers : 4
Special Characters : 2

Input : *GeEkS4GeEkS*
Output :
Upper case letters : 6
Lower case letters : 4
Numbers : 1
Special Characters : 2
"""

def count_upper_lower_num_specialchars(string):
    upper_count, lower_count, num_count, special_char_count = 0,0,0,0
    for char in string:
        if ord(char) in range(32,48) or ord(char) in range(59, 65)\
                or ord(char) in range(91, 97) or ord(char) in range(123, 127):
            special_char_count += 1
        elif ord(char) in range(48, 58):
            num_count += 1
        elif ord(char) in range(65, 91):
            upper_count += 1
        elif ord(char) in range(97, 123):
            lower_count += 1
    return upper_count, lower_count, num_count, special_char_count

print(count_upper_lower_num_specialchars('#GeeKs01fOr@gEEks07'))
print(count_upper_lower_num_specialchars('*GeEkS4GeEkS*'))

#print([chr(i) for i in range(32,48)]) - special chars
#print([chr(i) for i in range(48,58)]) - numbers
#print([chr(i) for i in range(59,65)]) - special chars
#print([chr(i) for i in range(65,91)]) - upper_case
#print([chr(i) for i in range(91,97)]) - special chars
#print([chr(i) for i in range(97,123)]) - lower_case
#print([chr(i) for i in range(123,127)]) - special chars