"""
Find the smallest number such that the sum of its digits is N and
it is divisible by 10^N.

Examples :

Input : N = 5
Output : 500000
500000 is the smallest number divisible
by 10^5 and sum of digits as 5.

Input : N = 20
Output : 29900000000000000000000
"""

def smallest_number_sum_N_divisible_10_pow_N(N):
    if N == 0:
        return '0'

    if N%9 != 0:
        print (N%9, end="")

    for i in range(1, int(N/9)+1):
        print("9", end="")
    #append N zeros

    for i in range(1, N+1):
        print("0" ,end="")


N1 = 5
N2 = 20
smallest_number_sum_N_divisible_10_pow_N(N2)

