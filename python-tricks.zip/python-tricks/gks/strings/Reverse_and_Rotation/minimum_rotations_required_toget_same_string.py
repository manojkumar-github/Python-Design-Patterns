"""
Minimum rotations required to get the same string
Given a string, we need to find the minimum number of rotations required to get the same string.

Examples:

Input : s = "geeks"
Output : 5

Input : s = "aaaa"
Output : 1
"""

def minimum_rotations_required_to_get_same_string(string):
    original_string = string
    n_rotations = 0
    n = len(string)
    while n_rotations < n:
        string = string[-1] + string[:n-1]
        n_rotations +=1
        if string == original_string:
            return n_rotations
    return n_rotations

print(minimum_rotations_required_to_get_same_string("geeks"))

