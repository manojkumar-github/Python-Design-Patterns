"""
Given an array of names of candidates in an election. A candidate name in array
 represents a vote casted to the candidate. Print the name of candidates
 received Max vote. If there is tie, print lexicographically smaller name.

Examples:

Input :  votes[] = {"john", "johnny", "jackie",
                    "johnny", "john", "jackie",
                    "jamie", "jamie", "john",
                    "johnny", "jamie", "johnny",
                    "john"};
Output : John
We have four Candidates with name as 'John',
'Johnny', 'jamie', 'jackie'. The candidates
John and Johny get maximum votes. Since John
is alphabetically smaller, we print it.
"""

import collections

def winner_of_a_election(votes):
    counter = collections.Counter(votes)
    max_vote = max(counter.values())
    winners = []
    for key in counter.keys():
        if counter[key] == max_vote:
            winners.append(key)
    return sorted(winners)[0]

votes = ["john", "johnny", "jackie",
                    "johnny", "john", "jackie",
                    "jamie", "jamie", "john",
                    "johnny", "jamie", "johnny",
                    "john"]

print(winner_of_a_election(votes))