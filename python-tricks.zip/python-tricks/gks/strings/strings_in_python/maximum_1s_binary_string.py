"""
We are given a binary string containing 1’s and 0’s.
Find maximum length of consecutive 1’
"""

def max_consecutive_1s(binary_string):
    count = 0
    max_length = 0
    for char in binary_string:
        if char is '1':
            count +=1
        else:
            max_length = max(max_length, count)
            count = 0

    return max_length

def max_consecutive_1s_using_split(binary_string):
    return max(map(len,binary_string.split('0')))

str = '11000111101010111'
print(max_consecutive_1s(str))

print (max_consecutive_1s_using_split(str))





