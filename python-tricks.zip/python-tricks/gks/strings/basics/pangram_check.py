#import string
#string.ascii_lowercase


seen_alphabets = []

def pangram_check(sentence):
    for char in sentence.lower():
        if char.isalpha() and char not in seen_alphabets:
            seen_alphabets.append(char)
            if len(seen_alphabets) == 26:
                return True
    return False




sentence = "The quick brown fox jumps over the little lazy dog"

print(pangram_check(sentence))
