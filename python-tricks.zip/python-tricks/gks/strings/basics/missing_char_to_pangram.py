seen_alphabets = []
alphabets = [chr(i) for i in range(ord('a'), ord('z')+1)]
def missing_char_to_pangram(sentence):
    for char in sentence.lower():
        if char not in seen_alphabets and char.isalpha():
            seen_alphabets.append(char)
            if len(seen_alphabets) == 26:
                return None
    return set(alphabets) - set(seen_alphabets)

print(missing_char_to_pangram("This is a sample sentence"))