

numbers =  [1, 1, 1, 3, 3, 2, 2, 2, 1, 1]

import itertools

for key, group in itertools.groupby(numbers):
    print(key, list(group))

from itertools import  groupby

def remove_consec_duplicates_with_groupby(string):
    result = ""
    for (key, group) in groupby(string):
        result += key
    return result

print(remove_consec_duplicates_with_groupby('aaaaabbbbbb'))

def remove_consec_duplictes_without_groupby(string):
    if string == "":
        return string
    i = 0
    if len(string) == 1:
        return string
    return ''.join(list(set(list(string))))

print(remove_consec_duplictes_without_groupby('aaaaabbbbbb'))





