seen_alphabets = []
def is_panagramic_lipogram(sentence):
    for char in sentence.lower():
        if char not in seen_alphabets and char.isalpha():
            seen_alphabets.append(char)
            if len(seen_alphabets) == 26:
                return "panagram"
    if len(seen_alphabets) == 25:
        return "panagramic_lipogram"
    else:
        return "lipogram"



sentence1 = "The quick brown fox jumped over the lazy dog"
print(is_panagramic_lipogram(sentence1))

sentence2 = "The quick brown fox jumps over the lazy dog"
print(is_panagramic_lipogram(sentence2))

sentence3 = "The quick brown fox jum over the lazy dog"
print(is_panagramic_lipogram(sentence3))