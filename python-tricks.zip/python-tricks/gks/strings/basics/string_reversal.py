def string_reverse(string):
    new_str = ""
    for char in string:
        new_str = char+new_str
    return new_str

print(string_reverse("abc"))
print("abc"[::-1])
