
def fn_to_copy_string(str1, str2):
    """Function should copy content of str2 to str1"""
    str2 = list(str2) # split a string into list of characters
    for i in range (len(str1)):
        str2[i] = str1[i]
    return ''.join(str2[:len(str1)])

str1 = "hello"
str2 = "geeksforgeeks"

print(fn_to_copy_string(str1, str2))

