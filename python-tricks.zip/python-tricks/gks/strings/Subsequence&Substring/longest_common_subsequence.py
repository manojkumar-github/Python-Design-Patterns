"""
Longest subsequence where every character appears at-least k times
Given a string and a number k, find the longest subsequence of a string
where every character appears at-least k times.

Examples:

Input : str = "geeksforgeek"
         k = 2
Output : geeskgeeks
Every character in the output
subsequence appears at-least 2
times.

Input : str = "aabbaabacabb"
          k = 5
Output : aabbaabaabb
"""
from collections import Counter

def longest_common_subseq_achar_k_times(string, k):
    longest_sub_seq = ""
    counter = Counter(string)
    characters_atleast_k_times = [key for key,
                                  value in counter.items() if value >= k]
    for char in string:
        if char in characters_atleast_k_times:
            longest_sub_seq += char
    return longest_sub_seq

print(longest_common_subseq_achar_k_times('aabbaabacabb', 5))
