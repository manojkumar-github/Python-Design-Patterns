"""
With the use of pseudo-private variable we can differentiate the varibles with same name when used in different classes,
thus, avoiding name collisions. (This is how Name Mangling works in Python)

Pseudo-private variable should be preceded by double underscores.
For an example a class with name "Actor" with a pseudo-private variable would be transformed to self._Actor__X

Again, this is not a truely privatization of variable
We can still modify the variable by calling with specific classname followed by variable (self._C1__X==77)
private instance attributes can be acheived via __getattr__

"""
# example where the class variable when used in C3 is overwritten by the class used last
class C1:
    def meth1(self): self.X = 88
    def meth2(self): print self.X
class C2:
    def metha(self): self.X = 99
    def methb(self): print self.X

class C3(C1, C2): pass
I = C3()


I.meth1();I.metha()
print I.__dict__
I.meth2(); I.methb()
print I.__dict__

print "_____________"

# example where class variable collisions are handled.
class C4:
    def meth1(self): self.__X = 88
    def meth2(self): print self.__X
class C5:
    def metha(self): self.__X = 99
    def methb(self): print self.__X

class C6(C4, C5): pass
I1 = C6()



I1.meth1();I1.metha()
print I1.__dict__
I1.meth2(); I1.methb()
print I1.__dict__