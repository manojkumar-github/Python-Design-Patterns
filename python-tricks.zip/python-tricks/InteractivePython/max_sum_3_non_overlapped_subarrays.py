For
every
new
number, search
left
to
find
the
first
value
x
that is smaller
than
the
current
value.
For
every
new
subsequence
that
contains
x, the
min
sum is equal
to
the
min
sum
of
all
subsequence
that
end
with x.For every new subsequence that doesn't contain x, the min is the new
number.

To
make
the
solution
O(N), we
keep
a
mono
increasing
list
with origional index, so there will be no repeated search for each new value.


class Solution:
    def sumSubarrayMins(self, A):
        """
        :type A: List[int]
        :rtype: int
        """
        minQueue = []
        dp = [a for a in A]
        for i, a in enumerate(A):
            if i > 0:
                while minQueue and minQueue[-1][0] > a:
                    minQueue.pop()
                if not minQueue:
                    index = -1
                else:
                    index = minQueue[-1][1]
                dp[i] += dp[i - 1] + (i - index - 1) * a
                if index >= 0:
                    dp[i] += dp[index]
                if index > 0:
                    dp[i] -= dp[index - 1]

            minQueue.append((a, i))
        return dp[len(A) - 1] % (10 ** 9 + 7)
