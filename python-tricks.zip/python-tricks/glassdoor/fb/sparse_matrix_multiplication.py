









"""
Given two sparse matrices, how would you compute the dot product?
"""

# Time Complexity is O(m*n*l) and Space Complexity - O(m*l)
# matrix1 shape = O(m*n) and matrix2 shape = O(n*l)
def matrix_multiplication_naive(matrix1, matrix2):

    n_row_matrix1 = len(matrix1)
    n_col_matrix1 = len(matrix1[0])
    n_row_matrix2 = len(matrix2)
    n_col_matrix2 = len(matrix2[0])
    #R = [[0]*n_col_matrix2]*n_col_matrix1
    R = [[0 for col in range(n_col_matrix2)] for row in range(n_row_matrix1)]
    computations = 0
    for i in range(n_row_matrix1):
        for j in range(n_col_matrix2):
            for k in range(n_col_matrix1):
                if matrix1[i][k] and matrix2[k][j]:
                    R[i][j] += matrix1[i][k] * matrix2[k][j]
                    computations +=1
    print(computations)
    return R



A = [[12, 7, 3],
     [4, 5, 6],
     [7, 8, 9]]

# take a 3x4 matrix
B = [[5, 8, 1, 2],
     [6, 7, 3, 0],
     [4, 5, 9, 1]]

A1 = [[1, 2],
      [3,4]]
B1 = [[3, 0, 0, 6],
      [7,0,0,10]]
print (matrix_multiplication_naive(A1, B1))





