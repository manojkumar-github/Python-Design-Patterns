"""
reTRIEval

Binary Search Tree : M * log N
Trie search : O(M)
"""
"""
class TrieNode(object):
    #key character acts as an index
    def __init__():
        isEndOfWord = False
"""