def parenthisis_validation(expression):
    """
    How to find if a given expression is a valid arithmetic expression?
    Eg:(())()) - Invalid expression, (()()) - Valid expression
    """
    stack = list()  #
    for op in expression:
        if op == '(':
            stack.append(op)
        else:
            stack.pop()

    if len(stack) != 0:
        return False
    else:
        return True

print (parenthisis_validation('(()())'))