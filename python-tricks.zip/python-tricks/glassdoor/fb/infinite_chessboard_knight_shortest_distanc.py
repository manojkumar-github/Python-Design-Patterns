"""
Given an infinite chessboard, find shortest distance for a
knight to move from position A to position B
"""