"""
given a binary image, count the number of 4-directional connected components.
"""