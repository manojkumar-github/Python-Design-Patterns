z = ["cat", "bat", "mat"]
x_ = ["c", "b", "a", "t"]
"""
Given two sets

words ["cat", "bat", "mat" )
ordering = [c,b,a,t]
Return TRUE when the words in words[] are sorted in lexographic order as in ordering[]  """

def is_true(item, x):
        cnt = 0
        for i in range(len(x)-1):
            if x[i] not in item:
                continue
            k = 1
            while k < len(x)-i:
                if x[i+k] not in item:
                    k += 1
                    continue
                if item.index(x[i]) < item.index(x[i+k]):
                    cnt += 1

                    if i == len(x)-2:
                        return True if cnt == len(item)-1 else False
                    break
        return False


for itm in z:
    if is_true(itm, x_):
        print "True"
    else:
        print "False"
