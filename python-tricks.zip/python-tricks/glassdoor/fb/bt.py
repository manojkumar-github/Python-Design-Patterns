class Node(object):
    def __init__(self, val):
        self.val = val
        self.left = None
        self.right = None


def print_pre_order(root):
    """
    Pass a tree and print all the nodes through pre_order traversal
    sequence :Root, Left, Right
    :param root(Node):
    :return: None
    """
    # ip = 1 2 4 5 3
    # op = 1 2 4
    # root = 4, root.left =  , root.right =
    if root is None:
        return
    # recursion
    print(root.val)

    print_pre_order(root.left) # 4
    print_pre_order(root.right)

if __name__ == "__main__":
    tree = Node(1)
    tree.left = Node(2)
    tree.left.left = Node(4)
    tree.left.right = Node(5)
    tree.right = Node(3)
    print_pre_order(tree)


