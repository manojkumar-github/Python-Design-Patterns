# Python program to merge 
# two sorted arrays 
  
# Merge arr1[0..n1-1] and  
# arr2[0..n2-1] into  
# arr3[0..n1+n2-1] 
def mergeArrays(arr1, arr2):
    arr3 = []
    n1, n2 = len(arr1), len(arr2)

    i = 0
    j = 0

    # Traverse both array 
    while i < n1 and j < n2: 
      
        # Check if current element  
        # of first array is smaller  
        # than current element of  
        # second array. If yes,  
        # store first array element  
        # and increment first array 
        # index. Otherwise do same  
        # with second array 
        if arr1[i] < arr2[j]: 
            arr3.append(arr1[i])
            i = i + 1
        else: 
            arr3.append(arr2[j])
            j = j + 1

    if i == n1:
        # while loop broke because of i
        # which means we are still left with n2
        arr3.extend(arr2[j:])

    if j == n2:
        # while loop broke because of j
        # which means we are still left with n1 remaining elements
        arr3.extend(arr1[i:])

    return arr3

  
# Driver code
arr1 = [1, 3, 3, 5, 7]
n1 = len(arr1)

arr2 = [2, 3,3,  4, 6, 8, 8]
print (mergeArrays(arr1, arr2))


