"""
How would you speed up your typical bit reversal algorithm?

Input : 11
Output : 13
(11)10 = (1011)2.
After reversing the bits we get:
(1101)2 = (13)10.

Input : 10
Output : 5
(10)10 = (1010)2.
After reversing the bits we get:
(0101)2 = (101)2
        = (5)10.
"""

def bit_reversal(num):
    binary_rep_rev = ""
    i = 0
    result = 0
    while num != 0:
        if num%2 != 0:
            binary_rep_rev += '1'
            i +=1
        else:
            binary_rep_rev += '0'
            i += 1
        num = num//2
    for i in range(len(binary_rep_rev)):
        if binary_rep_rev[i] == '1':
            result += 2**(len(binary_rep_rev)-1-i)
    return result

print (bit_reversal(10))


def reverseBits(n):
    """ O(num) number of bit digits"""

    rev = 0

    # traversing bits of 'n' from the right
    while (n > 0):

        # bitwise left shift 'rev' by 1
        rev = rev << 1

        # if current bit is '1'
        if (n & 1 == 1):
            rev = rev ^ 1

        # bitwise right shift 'n' by 1
        n = n >> 1

    # required number
    return rev


# Driver code
n = 10
print(reverseBits(n))