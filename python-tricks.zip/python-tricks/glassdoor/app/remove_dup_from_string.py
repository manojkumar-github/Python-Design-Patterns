"""
Given a string with a word, return a string with all duplicates deleted.
"""

def remove_string_duplicates(astring):
    new_str = ""
    for char in astring:
        if char not in new_str:
            new_str += char
    return new_str

print(remove_string_duplicates("aabbccddeeee"))

"""
Time Complexity: O(n) 
Space Complexity : O(1)
"""