"""
Given a m x n grid filled with non-negative numbers, find a path from top left
 to bottom right which minimizes the sum of all numbers along its path.

Note: You can only move either down or right at any point in time.


Input:
[
  [1,3,1],
  [1,5,1],
  [4,2,1]
]
Output: 7
"""


def matrix_shortest_sum(matrix):
    n_row = len(matrix)
    n_col = len(matrix[0])

    for i in range(n_row):
        for j in range(n_col):
            if i == 0 and j == 0:
                continue
            elif i == 0 and j > 0:
                matrix[i][j] += matrix[i][j-1]
            elif i > 0 and j == 0:
                matrix[i][j] += matrix[i-1][j]
            else:
                matrix[i][j] += min([matrix[i-1][j], matrix[i][j-1]])
    return matrix[i][j]

A = [
  [1,3,1],
  [1,5,1],
  [4,2,1]
]

print (matrix_shortest_sum(A))