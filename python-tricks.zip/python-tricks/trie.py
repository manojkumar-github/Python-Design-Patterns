class TrieNode(object):
    def __init__(self):
        # a map (dict)
        self.is_end_of_word = False
        pass


amap = {}
words = ['abc', 'abgl', 'cdf', 'abcd', 'lmn']

for word in words:
    for char in word:
        if char not in amap.keys():
            amap['a'] = 