#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only

"""
Batch Gradient Descent
Stochastic Graident Descent
Mini Batch Gradient Descent
"""