#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only

"""
Bag of Words model --> n-gram, term frequenceies
https://en.wikipedia.org/wiki/Bag-of-words_model
"""