#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2021. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only



def binary_search(alist, item):
    print(alist, item)
    if len(alist) == 0:
        return None
    else:
        mid_point = len(alist)//2
        if alist[mid_point] == item:
            return True
        elif alist[mid_point] < item:
            return binary_search(alist[mid_point:], item)
        elif alist[mid_point] > item:
            print(mid_point,item)
            return binary_search(alist[:mid_point], item)
        else:
            return False

print(binary_search([1,2,3,4,5], 1))
