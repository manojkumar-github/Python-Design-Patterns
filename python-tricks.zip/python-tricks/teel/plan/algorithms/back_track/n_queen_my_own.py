#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only





def n_queen_problem(board):



    for col_index in range(len(board)):

        if is_safe(board, )
