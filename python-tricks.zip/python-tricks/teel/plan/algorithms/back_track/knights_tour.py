#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only


def generate_knight_next_moves(point: tuple):
    two_right_one_up = (point[0] + 2, point[1] + 1)
    one_right_two_up = (point[0] + 1, point[1] + 2)
    two_left_one_up = (point[0] - 2, point[1] + 1)
    one_left_two_up = (point[0] -1, point[1] + 2)

    two_right_one_down = (point[0] + 2, point[1] - 1)
    one_right_two_down = (point[0] + 1, point[1] - 2)
    two_left_one_down = (point[0] - 2, point[1] - 1)
    one_left_two_down = (point[0] - 1, point[1] - 2)

    one_up_two_left = (point[0] + 1, point[1] - 2)
    one_up_two_right = (point[0] + 1, point[1] + 2)
    two_up_one_left = (point[0] + 2, point[1] - 1 )
    two_up_one_right = (point[0] + 1, point[1] + 2)

    one_down_two_right = (point[0] + 2, point[1] + 1)
    one_down_two_left = (point[0] + 2, point[1] + 1)
    two_down_one_right = (point[0] + 2, point[1] + 1)
    two_down_one_left = (point[0] + 2, point[1] + 1)




def knight_tour(N=8):

    board = [[0] * 8] * 8
    start = (0,0)



    print(board)


knight_tour()

