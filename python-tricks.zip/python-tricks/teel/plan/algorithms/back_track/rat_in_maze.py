#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only


def is_valid_move(maze, next_block: tuple):

    if next_block[0] <= len(maze) -1 and next_block[1] <= len(maze) - 1:
        # valid move
        # check if it is a blocked path
        if maze[next_block[0]][next_block[1]] == 1:
            return True
    return False

def is_path_exists_from_this_block(maze, this_block: tuple, destination):

    forward = (this_block[0], this_block[1] + 1)
    downward = (this_block[0] + 1, this_block[1])

    if forward == destination:
        return True
    elif downward == destination:
        return True
    elif is_valid_move(maze, forward):
        return is_path_exists_from_this_block(maze, forward, destination)
    elif is_valid_move(maze, downward):
        return is_path_exists_from_this_block(maze, downward, destination)
    else:
        return False


def is_rat_in_maze_path_exists(maze: list):

    source : tuple = (0,0)
    destination = (len(maze)-1, len(maze)-1)

    return is_path_exists_from_this_block(maze, source, destination)


if __name__ == "__main__":
    maze = [[1, 0, 0, 0],
            [1, 1, 0, 1],
            [0, 1, 0, 0],
            [1, 1, 1, 1]]

    print(is_rat_in_maze_path_exists(maze))


