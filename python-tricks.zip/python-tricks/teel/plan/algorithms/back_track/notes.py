#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only

"""
1) Solving the problem RECURSIVELY
2) by trying to build solution incrementally one piece at a time
3) removing those solutions that fail to satisfy the constraint

"""