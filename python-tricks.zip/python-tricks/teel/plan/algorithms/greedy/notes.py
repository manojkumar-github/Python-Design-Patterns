#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only


"""
1. Picking up the solution that gives the immediate benefit
2. Problems that gives us locally optimum leads to global solution
"""


