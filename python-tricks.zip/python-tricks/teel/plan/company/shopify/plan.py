#!/usr/bin.env python
# Copyright (C) Pearson Assessments - 2020. All Rights Reserved.
# Proprietary - Use with Pearson Written Permission Only

"""
About Shopify:

know about product
Khaled Hammouda - know about this team

Question to ask:
    - Memory management questions
    - Pipeline questions
    - Data Management questions
    - Research problems
    - Datasets' sizes, benchmarking
    - Shopify blog
    - Tech Stack

Expected questions:




Package: 220k CAD + stocks + relocation + sign on bonus + yearly bonus + canada
health benefits + other benefits

3. Life history


Priority:
1) Know about team and company
2) Prepare resume thoroughly
3) What is the best problem you solved.
4) Basis , definitions and implementations of all algorithms.
5) Design patters and python programming skills.
6) Printouts - all complexities, list and dict.
7) Job description and recommendation systems
8) jj
"""