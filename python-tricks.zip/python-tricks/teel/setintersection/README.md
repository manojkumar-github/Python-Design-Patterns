# InnerMedian:

### Issues:

1) Two for loops costing the function with time complexity O(m*n)
2) Logic fails for the case where lists have duplicate elements. In the given
   code there needs to be a condition to append the item only to the
   "interection list" when the item does not exist in the intersection.
3) Logic is incorrect. As the sorting step is missing, thus, producing,
   incorrect results.
