"""
Given an array of numbers find all the numbers that can be generated from it
using +-/() any where between the numbers.
Array can have positive, negative, and duplicate.
"""