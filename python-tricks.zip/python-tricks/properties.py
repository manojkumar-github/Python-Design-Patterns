'''
class P:

    def __init__(self, x):
        self.__x = x

    def get_x(self):
        return self.__x

    def set_x(self, x):
        self.__x = x

p1 = P(42)
p2 = P(4711)
print p1.get_x()
print p1.set_x(47)
print p1.get_x()

p1.set_x(p1.get_x()+p2.get_x())
print p1.get_x()

print "Pythonic way"


class PR:

    def __init__(self, x):
        self.x = x

pr1 = PR(42)
pr1.x = 47
pr2 = PR(4711)
pr1.x = pr1.x + pr2.x
print pr1.x

print "changing the logic accordingly"
print "you only have to change the set method"


class Pnew:

    def __init__(self, x):
        self.set_x(x)

    def get_x(self):
        return self.__x

    def set_x(self, x):
        if x < 0:
            self.__x = 0
        elif x >1000:
            self.__x = 1000
        else:
            self.__x = x
pnew1 = Pnew(42)
pnew1.set_x(-5)
print pnew1.get_x()

print "if we used public attributes in the implementation. For the new logic implementation, you have to break the interface"
print "Therefore, people use getters and setters in java therefore, we can change the implementation without having change the interface"
print "PYTHON HAS PROPERTIES"
'''

class P:

    def __init__(self,x):
        self.set_x(x)

    def get_x(self):
        return self.__x

    def set_x(self, x):
        if x < 0:
            self.__x = 0
        elif x > 1000:
            self.__x = 1000
        else:
            self.__x = x

    x = property(get_x, set_x)

#p1 = P(1001)
#print p1.x
class Celsius:
    def __init__(self, temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

man = Celsius()
print man.temperature
man.temperature = 37
print man.temperature
print man.to_fahrenheit()

print man.__dict__


class Celsius_1:
    def __init__(self, temperature = 0):
        self.set_temperature(temperature)

    def to_fahrenheit(self):
        return (self.get_temperature() * 1.8) + 32

    # new update
    def get_temperature(self):
        return self._temperature

    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        self._temperature = value # private variable

#c = Celsius_1(-277) # raises value error

c = Celsius_1(37)
print c.get_temperature()
c.set_temperature(10)
print c.get_temperature()
#c.set_temperature(-300) # raises value error

# private variables dont exist in python. They are simple norms
c._temperature = -300
print c.get_temperature()

"""
All the clients who implemented our previous class in their program have to modify their code from obj.temperature
to obj.get_temperature() and all assignments obj.temperature=val to obj.set_temperature(val)

This will cause problems and is not backward compatible. This is where property comes to rescue
"""

class Celsius_proper:
    def __init__(self, temperature = 0):
        self.temperature = temperature

    def to_fahrenheit(self):
        return (self.temperature * 1.8) + 32

    def get_temperature(self):
        print("Getting value")
        return self._temperature

    def set_temperature(self, value):
        if value < -273:
            raise ValueError("Temperature below -273 is not possible")
        print("Setting value")
        self._temperature = value

    temperature = property(get_temperature,set_temperature)

cp = Celsius_proper()
print cp.__dict__
"""
Any code that retrives the value of temperature will automatically call get_temperature() instead of dictionary (__dict__) lookup.
Similarly, any code that assigns a value to the temperature will call set_temperature()
"""

print cp.temperature