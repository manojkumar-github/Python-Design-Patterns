


"""
Create a list of 5 words
"""

alist = ['This', 'of', 'is', 'simple', 'wordeee', 'Five888888888']



alist_length_map = {}


for elem in alist:
    alist_length_map[elem] = len(elem)


sorted_values = sorted(list(alist_length_map.values()))

print(sorted_values)

sorted_list = []
for new_val in sorted_values:
    for key, val in alist_length_map.items():
        if val == new_val:
            if key not in sorted_list:
                sorted_list.append(key)
            #alist_length_map.pop(key)

print(sorted_list)


